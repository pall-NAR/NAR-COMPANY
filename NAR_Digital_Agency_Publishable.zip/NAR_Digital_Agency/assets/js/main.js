const menuToggle=document.getElementById('menuToggle');
const navLinks=document.getElementById('navLinks');
menuToggle.addEventListener('click',()=>{const open=navLinks.classList.toggle('open');menuToggle.setAttribute('aria-expanded',String(open));menuToggle.textContent=open?'✕':'☰'});
navLinks.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{navLinks.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.textContent='☰'}));
document.getElementById('year').textContent=new Date().getFullYear();
const revealObserver=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');revealObserver.unobserve(entry.target)}})},{threshold:.13});
document.querySelectorAll('.reveal:not(.visible)').forEach(el=>revealObserver.observe(el));
// Gentle pointer glow movement on desktop
if(matchMedia('(pointer:fine)').matches){document.addEventListener('pointermove',e=>{document.documentElement.style.setProperty('--mx',(e.clientX/window.innerWidth*100)+'%');document.documentElement.style.setProperty('--my',(e.clientY/window.innerHeight*100)+'%')},{passive:true})}
