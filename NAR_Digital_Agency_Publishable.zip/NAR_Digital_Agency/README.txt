NAR — DIGITAL GROWTH AGENCY
===========================

STRUKTUR
- index.html              Halaman utama
- assets/css/style.css    Gaya visual, gradien, responsif, animasi
- assets/js/main.js       Menu mobile, tahun otomatis, animasi scroll

CARA MEMBUKA
1. Ekstrak file ZIP.
2. Buka folder NAR_Digital_Agency.
3. Klik dua kali index.html untuk melihat website di browser.

CARA PUBLIKASI GRATIS (GitHub Pages)
1. Buat akun/login di GitHub.
2. Buat repository baru, misalnya nar-digital-agency.
3. Upload isi folder ini (index.html dan folder assets; jangan upload ZIP sebagai satu file).
4. Buka Settings > Pages.
5. Pada Build and deployment, pilih Deploy from a branch.
6. Pilih branch main dan folder /(root), lalu Save.
7. Tunggu proses selesai; GitHub akan menampilkan URL publik website.

ALTERNATIF NETLIFY
- Buka https://app.netlify.com/drop
- Seret folder hasil ekstrak ke area deploy (jika browser/akun mendukung folder upload).
- Ikuti instruksi Netlify untuk mendapatkan URL publik.

SEBELUM PUBLIKASI
- Ganti email contoh hello@naragency.id di index.html dengan kontak bisnis asli.
- Tinjau ulang seluruh teks dan layanan agar sesuai dengan bisnis NAR.
- Jangan menampilkan angka statistik/testimoni yang tidak didukung data nyata.
- Ini adalah landing page statis; belum memiliki backend, database, login, atau formulir yang menyimpan data.
